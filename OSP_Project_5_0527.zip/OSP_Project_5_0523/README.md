# ⛰ 산행 기록 어플

#### 설명
> 추가 예정

#### ✅ 기능
- [x] 메인화면
- 산행 기록
  - [x] polyline 그리기
- [ ] 기록함
- [ ] 보폭 기반 등산로 추천

#### 📌 Team 5
|조장|조원|조원|조원|
|:---:|:---:|:---:|:---:|
|[전인우](https://github.com/Indwoo)|[김승환](https://github.com/lixxce5017)|[이송원](https://github.com/songwon0327)|[정희원](https://github.com/heewoneha)|