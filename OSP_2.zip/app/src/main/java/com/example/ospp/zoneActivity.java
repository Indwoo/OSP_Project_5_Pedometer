package com.example.ospp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
// 기록함

import android.os.Bundle;

public class zoneActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zone_page);
    }
}